<?php
// DEFINE('DB_USER', 'root');
// DEFINE('DB_PASSWORD', '');
// DEFINE('DB_HOST', 'localhost');
// DEFINE('DB_NAME', 'akademik');
try{
	$kdb = new PDO('mysql:host=localhost;dbname=ekola', 'root', '');
	$kdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
	echo $e->getMessage();
}
?>