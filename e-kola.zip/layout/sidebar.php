<?php
$page = !empty($_GET['page']) ? $_GET['page'] : "1";
?>

<div class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>
                        <li> <a  href="index.php?page=1" ><i class="fa fa-tachometer" <?php if($page==1) { echo 'class="active"'; } else { echo 'class=""'; } ?>></i>Dashboard</a>
                           
                        </li>
                          <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-bar-chart"></i><span class="hide-menu">Statistik</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li <?php if($page==2) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                                    <a href="index.php?page=2">Produksi</a></li>
                                <li <?php if($page==3) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                                    <a href="index.php?page=3">Luas Panen</a></li>
                                <li <?php if($page==4) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                                    <a href="index.php?page=4">Produktifitas </a></li>
                            </ul>
                        </li>
                        <li class="nav-label">Features</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-suitcase"></i><span class="hide-menu">Data DB </span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li <?php if($page==5) { echo 'class="active"'; } else { echo 'class=""'; } ?> >
                                    <a href="index.php?page=5">Data Statistika</a></li>
                                <li <?php if($page==6) { echo 'class="active"'; } else { echo 'class=""'; } ?> >
                                    <a href="index.php?page=6">Data Komuditas</a></li>
                             </ul>
                        </li>
				
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-map-marker"></i><span class="hide-menu">Lokasi DB</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="map-google.html">Google</a></li>
                                <li><a href="map-vector.html">Vector</a></li>
                            </ul>
                        </li>
                        
                        </li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-user"></i><span class="hide-menu">User DB</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="form-basic.html">Basic Forms</a></li>
                                <li><a href="form-layout.html">Form Layout</a></li>
                                <li><a href="form-validation.html">Form Validation</a></li>
                                <li><a href="form-editor.html">Editor</a></li>
                                <li><a href="form-dropzone.html">Dropzone</a></li>
                            </ul>
                        </li>

                        </li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </div>

