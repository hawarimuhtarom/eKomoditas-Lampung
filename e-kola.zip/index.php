
        <!-- End header header -->
        <!-- Left Sidebar  -->
        
<?php
session_start();
/*
if(!isset($_SESSION['username'])){
    header("location:login.php");
}
if($_SESSION['lv_user']!=="admin" 
&& $_SESSION['lv_user']!=="user"
)
{
header("location:login.php");
}*/
$page = !empty($_GET['page']) ? $_GET['page'] : "1";

?>

<?php
 include('header.php');
 ?>
<div class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>
                        <li> <a  href="index.php?page=1" ><i class="fa fa-tachometer" <?php if($page==1) { echo 'class="active"'; } else { echo 'class=""'; } ?>></i>Dashboard</a>
                           
                        </li>
                          <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-bar-chart"></i><span class="hide-menu">Statistika</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li <?php if($page==2) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                                    <a href="index.php?page=2">Produksi</a></li>
                                <li <?php if($page==3) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                                    <a href="index.php?page=3">Luas Panen</a></li>
                                <li <?php if($page==4) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                                    <a href="index.php?page=4">Produktivitas </a></li>
                            </ul>
                        </li>
                        <li class="nav-label">Features</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-suitcase"></i><span class="hide-menu">Data Tabel</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li <?php if($page==5) { echo 'class="active"'; } else { echo 'class=""'; } ?> >
                                    <a href="index.php?page=5">Data Produksi</a></li>
                                 <li <?php if($page==6) { echo 'class="active"'; } else { echo 'class=""'; } ?> >
                                    <a href="index.php?page=6">Data Luas Panen</a></li>
                                  <li <?php if($page==7) { echo 'class="active"'; } else { echo 'class=""'; } ?> >
                                    <a href="index.php?page=7">Data Produktivitas</a></li>
                                <li <?php if($page==8) { echo 'class="active"'; } else { echo 'class=""'; } ?> >
                                    <a href="index.php?page=8">Data Komuditas</a></li>
                             </ul>
                        </li>
				
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-map-marker"></i><span class="hide-menu">Lokasi </span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li <?php if($page==9) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                                    <a href="index.php?page=9">Data Lokasi</a></li>
                                <li <?php if($page==10) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                                    <a href="index.php?page=10">Maps Lokasi</a></li>
                            </ul>
                        </li>
                        
                        </li>
                        <li   
                            <?php 
                              
                                    if($page==11 ) { echo 'class="active"'; } else { echo 'class=""'; } 
                                
                                    
                            ?>> 
                            <?php if(isset($_SESSION['lv_user'])){?>
                            <a  href="index.php?page=11" ><i class="fa fa-user"></i><span  class="hide-menu">Pengaturan Akun </span></a>
                            <?php }?>
                        </li>

                        </li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </div>


        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- Bread crumb -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h4 class="text-primary">PUSAT DATA STATISTIK KOMODITAS LAMPUNG</h4> </div>
                
            </div>
            <!-- End Bread crumb -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- Start Page Content -->
                <div class="row">
                   	
<?php	
switch($page)
{
case('1'): include_once('./page/home.php'); break;	
case('2'): include_once('./page/produksi.php'); break;		
case('3'): include_once('./page/luaspanen.php'); break;	
case('4'): include_once('./page/produktivitas.php'); break;   					
case('5'): include_once('./page/db_produksi.php'); break;  	
case('6'): include_once('./page/db_luaspanen.php'); break;  	
case('7'): include_once('./page/db_produktivitas.php'); break; 
case('8'): include_once('./page/db_komoditas.php'); break;  
case('9'): include_once('./page/db_lokasi.php'); break;  	
case('10'): include_once('./page/db_maps.php'); break;  
case('11'): include_once('./page/db_user.php'); break; 
default:   include_once('./page/home.php'); break;
}			
?>
                </div>
             <!-- End PAge Content -->
            </div>
            <!-- End Container fluid  -->
            <!-- footer -->
 <?php
 include('footer.php');
 ?> 