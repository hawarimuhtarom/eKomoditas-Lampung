<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>E - KOLA </title>
    <!-- Bootstrap Core CSS -->
 
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->

    <link href="css/lib/calendar2/semantic.ui.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    
    <script src="js/lib/jquery/jquery.min.js"></script>
    <script src="./js/chartjs.php"></script>
    <script src="./js/chartbundle.php"></script>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:** -->
    <!--[if lt IE 9]>
    <script src="https:**oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https:**oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<?php
session_start();

try{
	$kdb = new PDO('mysql:host=localhost;dbname=ekola', 'root', '');
	$kdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
	echo $e->getMessage();
}
$username = $_POST['username'];
//$psw = $_POST['password'];
$psw = md5($_POST['password']);
$op = $_GET['op'];


if($op=="in"){
$cek = $kdb->query("SELECT * FROM user WHERE username='$username' AND password='$psw' AND publish='T' ");
if($cek->rowCount($cek)==1){
$c = $cek->fetch(PDO::FETCH_ASSOC);
$_SESSION['username'] = $c['username'];
$_SESSION['nmuser'] = $c['nmuser'];
$_SESSION['lv_user'] = $c['lv_user'];
if($c['lv_user']=="admin") {
header("location:index.php");
}
else {
header("location:index.php");
}
//header("location:index.php");
}else{
die('
    <!-- Main wrapper  -->
    <div class="error-page" id="wrapper">
        <div class="error-box">
            <div class="error-body text-center">
                <h1>WOW</h1>
                <img src="upload/keys.png"> </br>
                <h3 class="text-uppercase"> SALAH USERNAME / PASSWORD  </h3>
                <p class="text-muted m-t-30 m-b-30">Periksa dan Ingat - Ingat Username dan Password Anda</p>
                <a class="btn btn-info btn-rounded waves-effect waves-light m-b-40" href="index.php">Back to Home</a>
                <a class="btn btn-success btn-rounded waves-effect waves-light m-b-40" href="login.php">Back to Login</a></div>
            <footer class="footer text-center">&copy; 2018 E-Kola | Pusat Data Statistik Komoditas Lampung.</footer>
        </div>
    </div>'
        );
}
}else if($op=="out"){
    session_destroy();
//unset($_SESSION['nmuser']);
header("location:index.php");
}
?>