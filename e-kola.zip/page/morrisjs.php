<?php
try{
	$kdb = new PDO('mysql:host=localhost;dbname=ekola', 'root', '');
	$kdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
	echo $e->getMessage();
}
?>

<script>

// Dashboard 1 Morris-chart

$( function () {
	"use strict";

	// Extra chart
	Morris.Area( {
		element: 'produksi',
		data: [ 
                    <?php 
                    $nilaimin = $kdb->query("SELECT min(tahun) FROM data_produksi");
                    $nmin = $nilaimin->fetch();
                    $nilaimax = $kdb->query( "SELECT max(tahun) FROM data_produksi");
                    $nmax = $nilaimax->fetch();
                    
                    
                    for ($i= $nmin[0]; $i <= $nmax[0]; $i++){ ?>
                { 
                             period: <?php  echo "'".$i."'"; ?>,
                    <?php 
                    $sqlquery = "SELECT ton as ton, nm_kabupaten as namakab,tahun FROM `data_produksi`inner join kabupaten on data_produksi.id_kabupaten = kabupaten.id_kabupaten where tahun = ".$i." group by data_produksi.tahun , data_produksi.id_kabupaten";
                    $hasilquery = $kdb->query( $sqlquery);
                    while ( $baris = $hasilquery->fetch()){
                     ?>
                          <?php echo "'".$baris['namakab']."'"; ?> : <?php echo $baris['ton'].","; ?>    
                          <?php 
                               }
                            ?>
                },
                    <?php } ?>                        
                ],
		lineColors: [ '#26DAD2', '#fc6180', '#62d1f3', '#ffb64d', '#4680ff' ],
		xkey: 'period',
                
                 
                                     
		ykeys: [ 'Lampung Barat','Lampung Selatan','Lampung Tengah','Lampung Timur','Lampung Utara'],
		labels: [ 'Lampung Barat','Lampung Selatan','Lampung Tengah','Lampung Timur','Lampung Utara'],
		pointSize: 2,
		lineWidth: 2,
		resize: true,
		fillOpacity: 0.2,
		behaveLikeLine: true,
		gridLineColor: '#e0e0e0',
		hideHover: 'auto'


	} );

 
} );	

$( function () {
	"use strict";

       Morris.Area( {
		element: 'luaspanen',
		data: [ 
                    <?php 
                    $nilaimin = $kdb->query("SELECT min(tahun) FROM data_luaspanen");
                    $nmin = $nilaimin->fetch();
                    $nilaimax = $kdb->query( "SELECT max(tahun) FROM data_luaspanen");
                    $nmax = $nilaimax->fetch();
                    
                    
                    for ($i= $nmin[0]; $i <= $nmax[0]; $i++){ ?>
                { 
                             period: <?php  echo "'".$i."'"; ?>,
                    <?php 
                    $sqlquery = "SELECT hektar as hektar, nm_kabupaten as namakab,tahun FROM `data_luaspanen` inner join kabupaten on data_luaspanen.id_kabupaten = kabupaten.id_kabupaten where tahun = ".$i." group by data_luaspanen.tahun , data_luaspanen.id_kabupaten";
                    $hasilquery = $kdb->query( $sqlquery);
                    while ( $baris = $hasilquery->fetch()){
                     ?>
                          <?php echo "'".$baris['namakab']."'"; ?> : <?php echo $baris['hektar'].","; ?>    
                          <?php 
                               }
                            ?>
                },
                    <?php } ?>                        
                ],
		lineColors: [ '#26DAD2', '#fc6180', '#62d1f3', '#ffb64d', '#4680ff' ],
		xkey: 'period',
		ykeys: [ 'Lampung Barat','Lampung Selatan','Lampung Tengah','Lampung Timur','Lampung Utara'],
		labels: [ 'Lampung Barat','Lampung Selatan','Lampung Tengah','Lampung Timur','Lampung Utara'],
		pointSize: 2,
		lineWidth: 2,
		resize: true,
		fillOpacity: 0.2,
		behaveLikeLine: true,
		gridLineColor: '#e0e0e0',
		hideHover: 'auto'


	} );

} );


$( function () {
	"use strict";

       Morris.Area( {
		element: 'produktivitas',
		data: [ 
                    <?php 
                    $nilaimin = $kdb->query("SELECT min(tahun) FROM data_produtivitas");
                    $nmin = $nilaimin->fetch();
                    $nilaimax = $kdb->query( "SELECT max(tahun) FROM data_produtivitas");
                    $nmax = $nilaimax->fetch();
                    
                    
                    for ($i= $nmin[0]; $i <= $nmax[0]; $i++){ ?>
                { 
                             period: <?php  echo "'".$i."'"; ?>,
                    <?php 
                    $sqlquery = "SELECT kuintal_hektar as kuintal_hektar, nm_kabupaten as namakab,tahun FROM `data_produtivitas` inner join kabupaten on data_produtivitas.id_kabupaten = kabupaten.id_kabupaten where tahun = ".$i." group by data_produtivitas.tahun , data_produtivitas.id_kabupaten";
                    $hasilquery = $kdb->query( $sqlquery);
                    while ( $baris = $hasilquery->fetch()){
                     ?>
                          <?php echo "'".$baris['namakab']."'"; ?> : <?php echo $baris['kuintal_hektar'].","; ?>    
                          <?php 
                               }
                            ?>
                },
                    <?php } ?>                        
                ],
		lineColors: [ '#26DAD2', '#fc6180', '#62d1f3', '#ffb64d', '#4680ff' ],
		xkey: 'period',
		ykeys: [ 'Lampung Barat','Lampung Selatan','Lampung Tengah','Lampung Timur','Lampung Utara'],
		labels: [ 'Lampung Barat','Lampung Selatan','Lampung Tengah','Lampung Timur','Lampung Utara'],
		pointSize: 2,
		lineWidth: 2,
		resize: true,
		fillOpacity: 0.2,
		behaveLikeLine: true,
		gridLineColor: '#e0e0e0',
		hideHover: 'auto'
	} );
        } );
 


	Morris.Donut( {
		element: 'donchart',
		data: [ 
                <?php 
                    $sqlquery1 = "SELECT max(tahun) as tahun FROM data_produksi";
                    $hasilquery1 = $kdb->query( $sqlquery1);
                    $baris1 = $hasilquery1->fetch();
                    
                    $sqlquery = "SELECT ton , nm_kabupaten FROM `data_produksi`, kabupaten WHERE data_produksi.id_kabupaten = kabupaten.id_kabupaten AND tahun=".$baris1['tahun']."";
                    $hasilquery = $kdb->query( $sqlquery);
                    while ( $baris = $hasilquery->fetch()){
                     ?>
                {
                    
			label: <?php echo "'".$baris['nm_kabupaten']."'"; ?>,
			value: <?php echo "'".$baris['ton']."'"; ?>,
                        

        },<?php }?> ],
		resize: true,
		colors: [ '#26DAD2', '#fc6180', '#62d1f3', '#ffb64d', '#4680ff'  ]
	} );  



</script>
