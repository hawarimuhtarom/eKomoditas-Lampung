<?php
include 'koneksi/koneksi.php';
?>              
<div class="col-lg-12"> 
<div class="row bg-white m-l-0 m-r-0 box-shadow ">

                    <!-- column -->
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Statistika Produksi Padi Lampung (TON / Tahun)</h4>
                                <div id="produksi"></div>
                            </div>
                        </div>
                    </div>
                    <!-- column -->

                    <!-- column -->
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-body browser">
                                <h6 class="card-title">Persentase (%) Produksi Padi Lampung</h6>
                                <hr>
                                <p class="f-w-600">Lampung Selatan <span class="pull-right">
                                <?php
                                     $sqlquery = "SELECT ROUND( SUM(ton) / (SELECT SUM(ton) FROM data_produksi ) * 100) as presentase FROM data_produksi WHERE id_kabupaten = 2";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo $baris['presentase']."%"; 
                                    ?>
                                </span></p>
                                <div class="progress ">
                                    <div role="progressbar" style="width: 
                                    <?php
                                     $sqlquery = "SELECT ROUND( SUM(ton) / (SELECT SUM(ton) FROM data_produksi ) * 100) as presentase FROM data_produksi WHERE id_kabupaten = 2";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo $baris['presentase']."%"; 
                                    ?>
                                         ; height:8px;" class="progress-bar bg-danger wow animated progress-animated"> <span class="sr-only"></span> </div>
                                </div>

                                <p class="m-t-30 f-w-600">Lampung Tengah<span class="pull-right">
                                    <?php
                                     $sqlquery = "SELECT ROUND( SUM(ton) / (SELECT SUM(ton) FROM data_produksi ) * 100) as presentase FROM data_produksi WHERE id_kabupaten = 3";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo $baris['presentase']."%"; 
                                    ?>
                                    </span></p>
                                <div class="progress">
                                    <div role="progressbar" style="width: 
                                    <?php
                                     $sqlquery = "SELECT ROUND( SUM(ton) / (SELECT SUM(ton) FROM data_produksi ) * 100) as presentase FROM data_produksi WHERE id_kabupaten = 3";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo $baris['presentase']."%"; 
                                    ?>
                                         ; height:8px;" class="progress-bar bg-info wow animated progress-animated"> <span class="sr-only"></span> </div>
                                </div>

                                <p class="m-t-30 f-w-600">Lampung Barat<span class="pull-right">
                                    <?php
                                     $sqlquery = "SELECT ROUND( SUM(ton) / (SELECT SUM(ton) FROM data_produksi ) * 100) as presentase FROM data_produksi WHERE id_kabupaten = 1";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo $baris['presentase']."%"; 
                                    ?>
                                    </span></p>
                                <div class="progress">
                                    <div role="progressbar" style="width: 
                                         <?php
                                     $sqlquery = "SELECT ROUND( SUM(ton) / (SELECT SUM(ton) FROM data_produksi ) * 100) as presentase FROM data_produksi WHERE id_kabupaten = 1";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo $baris['presentase']."%"; 
                                    ?>; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only"></span> </div>
                                </div>

                                <p class="m-t-30 f-w-600">Lampung Timur<span class="pull-right">
                                    <?php
                                     $sqlquery = "SELECT ROUND( SUM(ton) / (SELECT SUM(ton) FROM data_produksi ) * 100) as presentase FROM data_produksi WHERE id_kabupaten = 4";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo $baris['presentase']."%"; 
                                    ?>
                                    </span></p>
                                <div class="progress">
                                    <div role="progressbar" style="width: 
                                     <?php
                                     $sqlquery = "SELECT ROUND( SUM(ton) / (SELECT SUM(ton) FROM data_produksi ) * 100) as presentase FROM data_produksi WHERE id_kabupaten =  4";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo $baris['presentase']."%"; 
                                    ?>; height:8px;" class="progress-bar bg-warning wow animated progress-animated"> <span class="sr-only"></span> </div>
                                </div>

				<p class="m-t-30 f-w-600">Lampung Utara<span class="pull-right">
                                    <?php
                                     $sqlquery = "SELECT ROUND( SUM(ton) / (SELECT SUM(ton) FROM data_produksi ) * 100) as presentase FROM data_produksi WHERE id_kabupaten = 5";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo $baris['presentase']."%"; 
                                    ?>
                                    </span></p>
                                <div class="progress m-b-30">
                                    <div role="progressbar" style="width: 
                                    <?php
                                     $sqlquery = "SELECT ROUND( SUM(ton) / (SELECT SUM(ton) FROM data_produksi ) * 100) as presentase FROM data_produksi WHERE id_kabupaten = 5";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo $baris['presentase']."%"; 
                                    ?>
                                         ; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only"></span> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- column -->
                </div>
                   </div>


<div class="col-lg-12">
                        <div class="card">
                            <div class="card-title">
                                <h4>Rata Rata Produksi Padi TON Per-Tahun  </h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Rata - Rata</th>
                                                <th>Tahun</th>
                                            </tr>
                                        </thead>
                                        <tbody>
<?php
    $sqlquery = "SELECT round(avg(ton)) as rata, tahun FROM `data_produksi` group by data_produksi.tahun";
    $hasil = $kdb->query( $sqlquery);

  while($baris = $hasil->fetch(PDO::FETCH_ASSOC))
{
?>
                                            
                                            <tr>
                                                <td>
                                                    <div class="round-img">
                                                        <a href=""><img src="./upload/rice.png" ></a>
                                                    </div>
                                                </td>
                                               <td><span class="badge badge-primary"><?php echo $baris['rata']; ?> TON</span></td>
                                                <td><span class="badge badge-danger"><?php echo $baris['tahun']; ?></span></td>
                                            </tr>
<?php
  }
  ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>