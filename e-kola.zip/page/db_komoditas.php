<?php
$a = !empty($_GET['a']) ? $_GET['a'] : "reset";
$id_komoditas = !empty($_GET['id']) ? $_GET['id'] : " ";   
$kdb = koneksidatabase();
$a = @$_GET["a"];
$sql = @$_POST["sql"];
switch ($sql) {
    case "insert": sql_insert(); break;
    case "update": sql_update(); break;
    case "delete": sql_delete(); break;	
}

switch ($a) {
    case "reset" :  curd_read();   break;
    case "tambah":  curd_create(); break;	
    case "edit"  :  curd_update($id_komoditas); break;	
    case "hapus"  :  curd_delete($id_komoditas); break;  	
    default : curd_read(); break;
}


function curd_read()
{ 
  $hasil = sql_select();
  $i=1;

  ?>
<div class="col-md-12"> 
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Data Komoditas   </h4>
                                <h6 class="card-subtitle">Mengatur data Komoditas di daerah Kabupaten Lampung</h6>
                                <?php if(isset($_SESSION['lv_user'])){?>
                                <?php if(($_SESSION['lv_user']=='admin')){?>
                                <a href="index.php?page=8&a=tambah"><span class='btn  btn-success btn-sm'>TAMBAH DATA</span></a>	
                                <?php }}?>
                                <div class="table-responsive m-t-40">
                                    <table id="myTable" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th> Nama Komoditas</th>
                                                <?php if(isset($_SESSION['lv_user'])){?>
                                                <?php if(($_SESSION['lv_user']=='admin')){?>
                                                <th>Action</th>
                                                <?php }}?>
                                                                                              
                                            </tr>
                                        </thead>
                                        <tbody>
 <?php
  while($baris = $hasil->fetch(PDO::FETCH_ASSOC))
  {
  ?>
                                            <tr>
  <td><?php echo $i; ?></td>
  <td><?php echo $baris['nm_komoditas']; ?></td>
   <?php if(isset($_SESSION['lv_user'])){?>
  <?php if(($_SESSION['lv_user']=='admin')){?>
  <td>
                                                      <a  href="index.php?page=8&a=edit&id=<?php echo $baris['id_komoditas']; ?>"><span class='btn  btn-warning btn-sm'>UPDATE</span></a>
                                                    <a  href="index.php?page=8&a=hapus&id=<?php echo $baris['id_komoditas']; ?>"><span class='btn  btn-danger btn-sm'>DELETE</span></a>	
                                                </td>
                                                  <?php }}?>
                                            </tr>
 <?php
   $i++;  
  }
  ?>
                                        </tbody>
                                    </table>
 <?php
}
 ?>
                                </div>
                            </div>
                        </div>
</div>

<?php 
function formeditor($row)
  {
?>
<div class="container-fluid">
<div class="row">
<div class="col-lg-12"> 
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Data Lokasi </h4>
                                <h6 class="card-subtitle">Data Lokasi daerah Kabupaten Lampung</h6>   
                                <a href="index.php?page=8&a=reset"><span class='btn  btn-warning btn-sm'>Batal</a>
<br>
                                <div class="table-responsive m-t-40">
                                    <table id="myTable" class="table table-hover">
                                        <thead>

<tr>
<td >Nama Komoditas </td>
<td class="form-group" ><input class="form-control"  type="text" name="nm_komoditas" id="nm_komoditas" maxlength="25"  value="<?php  echo trim($row["nm_komoditas"]) ?>" ></td>
</tr>

 </thead>
 <tbody> </tbody>
</table>
</div>
 <p><input class="btn btn-success btn-sm"  type="submit" name="action" value="Simpan" ></p>
 </div>
 </div>
</div>
  </div>
    </div>
<?php  }?>	
<?php 
function curd_create() 
{
?>

<form action="index.php?page=8&a=reset" method="post">
<input type="hidden" name="sql" value="insert" >
<?php
$row = array(
  "nm_komoditas" => ""
   ) ;
formeditor($row)
?>


</form>
<?php } ?>

<?php 
function curd_update($id_komoditas) 
{
global $kdb;
$hasil2 = sql_select_byid($id_komoditas);
$row =  $hasil2->fetch(PDO::FETCH_ASSOC);
?>

<br>
<form action="index.php?page=8&a=reset" method="post">
<input type="hidden" name="sql" value="update" >
<input type="hidden" name="id_komoditas" value="<?php  echo $id_komoditas; ?>" >
<?php
formeditor($row)
?>
</form>
<?php } ?>

<?php 
function curd_delete($id_komoditas) 
{
global $kdb;
$hasil2 = sql_select_byid($id_komoditas);
$row =  $hasil2->fetch(PDO::FETCH_ASSOC);
?>

<div class="container-fluid">
<div class="row">

<div class="col-lg-12"> 
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Penghapusan Data</h4>
<a href="index.php?page=8&a=reset"><span class='btn  btn-warning btn-sm'>Batal</a>
<br>
<form action="index.php?page=8&a=reset" method="post">
<input type="hidden" name="sql" value="delete" >
<input type="hidden" name="id_komoditas" value="<?php  echo $id_komoditas; ?>" >
<h5> Anda yakin akan menghapus data  </h5>
<p><input type="submit" name="action" value="Delete" ></p>
                            </div>
                            </div>
    </div>
    </div>
    </div>
</form>
<?php } ?>


<?php 
function koneksidatabase()
{
    include('./koneksi/koneksi.php');
	return $kdb;
}

function sql_select_byid($id_komoditas)
{
  global $kdb;
  $hasil2 = $kdb->query(" select * from komoditas where id_komoditas = ".$id_komoditas);
  return $hasil2;
}
function sql_select()
{
  global $kdb;
  $sql = "select * from komoditas";
  $hasil2 = $kdb->query($sql);
  return $hasil2;
  
}

function sql_insert()
{
  global $kdb;
  global $_POST; 
  
  $nm_komoditas = $_POST["nm_komoditas"];
  $sql  = $kdb->query("INSERT INTO komoditas(nm_komoditas) VALUES ('$nm_komoditas')");			  
  
}

function sql_update()
{
 global $kdb;
  global $_POST; 
  $id_komoditas = $_POST["id_komoditas"];
  $nm_komoditas = $_POST["nm_komoditas"];
    $sql  = $kdb->query("UPDATE `komoditas` SET `nm_komoditas` = '$nm_komoditas' WHERE `komoditas`.`id_komoditas` = ".$id_komoditas);			  
}

function sql_delete()
{
  global $kdb;
  global $_POST; 
  $sql  = $kdb->query(" delete from `komoditas` where id_komoditas = ".$_POST["id_komoditas"]);			  
 
}
?>