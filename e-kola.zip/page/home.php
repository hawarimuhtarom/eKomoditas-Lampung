<?php
include 'koneksi/koneksi.php';

?>
<style type="text/css">
div.jumbotron {

background-image:url(upload/jumbo.jpg); 
width: 100%;
hieght : 100%;
background-size: 100%; 
 
}
</style>

<div class="container">
  <div class="jumbotron">
      <h1><font color=white>e - KOMODITAS LAMPUNG</font></h1> 
      <p><font color=white>Menampilkan data - data statistika berbagai komoditas di Lampung dari berbagai kabupaten sehingga bisa melihat perkembangan pertanian di Lampung</font></p> 
  </div>
</div>
<div class="col-md-3">
                        <div class="card p-30">
                            <div class="media">
                                <div class="media-left meida media-middle">
                                    <span><i class="fa fa-map f-s-40 color-primary"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h5><?php
                                     $sqlquery = "SELECT b.nm_kabupaten as namakab, a.hektar as hektar FROM data_luaspanen as a , kabupaten as b WHERE hektar =( SELECT MAX(hektar) as luas FROM `data_luaspanen`) AND a.id_kabupaten = b.id_kabupaten";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo $baris['namakab']."</br>"; 
                                     echo $baris['hektar']." Hektar";
                                    ?>
                                    </h5>
                                    <p class="m-b-0">Panen Terluas </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-30">
                            <div class="media">
                                <div class="media-left meida media-middle">
                                    <span><i class="fa fa-shopping-cart f-s-40 color-success"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h5><?php
                                     $sqlquery = "SELECT b.nm_kabupaten as namakab, a.ton as ton FROM data_produksi as a , kabupaten as b WHERE ton =( SELECT MAX(ton) as ton FROM `data_produksi`) AND a.id_kabupaten = b.id_kabupaten";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo $baris['namakab']."</br>"; 
                                     echo $baris['ton']." Ton";
                                    ?>
                                    </h5>
                                    <p class="m-b-0">Panen Terbanyak</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-30">
                            <div class="media">
                                <div class="media-left meida media-middle">
                                    <span><i class="fa fa-archive f-s-40 color-warning"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                                   <h5><?php
                                     $sqlquery = "SELECT COUNT(*) as jumlah from komoditas";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo "Komoditi Terdaftar</br>"; 
                                     echo $baris['jumlah'];
                                    ?>
                                    </h5>
                                    <p class="m-b-0">Komoditas</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-30">
                            <div class="media">
                                <div class="media-left meida media-middle">
                                    <span><i class="fa fa-map-marker f-s-40 color-danger"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h5><?php
                                     $sqlquery = "SELECT COUNT(*) as jumlah from kabupaten";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                     
                                     echo "Kabupaten Terdaftar</br>"; 
                                     echo $baris['jumlah'];
                                    ?>
                                    </h5>
                                    <p class="m-b-0">Lokasi Kabupaten</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row bg-white m-l-0 m-r-0 box-shadow ">

                    <!-- column -->
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body">
                                <?php 
                                $sqlquery = "SELECT max(tahun) as tahun FROM data_produksi";
                               $hasilquery = $kdb->query( $sqlquery);
                                $baris = $hasilquery->fetch();
                                echo'<h4 class="card-title">Produksi Padi (TON) Lampung Tahun '.$baris['tahun'].'</h4>'
                                ?>
                                <div id="donchart"></div>
                            </div>
                        </div>
                    </div>
                    <!-- column -->

                    <!-- column -->
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-body browser">
                                <?php
                                     $sqlquery = "SELECT a.*, b.nmuser, c.nm_komoditas FROM `post`as a , user as b, komoditas as c WHERE a.id_komoditas=c.id_komoditas and a.id_user=b.id_user";
                                     $hasilquery = $kdb->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                    
                                    echo' <h4 class="f-w-600">'.$baris['title'].' </h4>';
                                    echo'<span align="justify"> <p> '.$baris['deskripsi'].'</p></span>';
                                    echo'  <hr/> <p class="f-w-600"> Kategori : '.$baris['nm_komoditas'].'</p>';
                                        ?>
                            </div>
                        </div>
                    </div>
                    <!-- column -->
                </div>
                <div class="row">
			
<?php
include 'page/author.php';
?>