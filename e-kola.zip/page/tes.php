

<?php
// DEFINE('DB_USER', 'root');
// DEFINE('DB_PASSWORD', '');
// DEFINE('DB_HOST', 'localhost');
// DEFINE('DB_NAME', 'akademik');
try{
	$kdb = new PDO('mysql:host=localhost;dbname=ekola', 'root', '');
	$kdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
	echo $e->getMessage();
}
?>

<?php

    $sqlquery = "SELECT sum(ton) as ton, nm_kabupaten as namakab,tahun FROM `data_produksi`";
    $sqlquery .= " inner join kabupaten on data_produksi.id_kabupaten = kabupaten.id_kabupaten ";
    $sqlquery .= "group by data_produksi.tahun, data_produksi.id_kabupaten";
    $hasilquery = $kdb->query( $sqlquery);
 
// Dashboard 1 Morris-chart
    ?>

<script>
    
$( function () {
	"use strict";
        // Extra chart
	Morris.Area( {
		element: 'extra-area-chart',
 <?php
 while ( $baris = $hasilquery->fetch()) 
 {
  ?>
		data: [ {
				period:<?php echo  $baris["tahun"];?>,
				<?php echo  $baris["namakab"];?>: <?php echo  $baris["ton"];?>
<?php
}
 ?>
				imac: 10,
				ibook: 100,
				samsung: 10,
				android: 10
        }, {
				period: '2002',
				iphone: 10,
				imac: 60,
				ibook: 40,
				samsung: 80,
				android: 120
        }, {
				period: '2003',
				iphone: 120,
				imac: 10,
				ibook: 90,
				samsung: 30,
				android: 50
        }, {
				period: '2004',
				iphone: 0,
				imac: 0,
				ibook: 120,
				samsung: 0,
				android: 0
        }, {
				period: '2005',
				iphone: 0,
				imac: 0,
				ibook: 0,
				samsung: 150,
				android: 0
        }, {
				period: '2006',
				iphone: 160,
				imac: 75,
				ibook: 30,
				samsung: 60,
				android: 90
        }, {
				period: '2007',
				iphone: 10,
				imac: 120,
				ibook: 40,
				samsung: 60,
				android: 30
        }


        ],
		lineColors: [ '#26DAD2', '#fc6180', '#62d1f3', '#ffb64d', '#4680ff' ],
		xkey: 'period',
		ykeys: [ 'iphone', 'imac', 'ibook', 'samsung', 'android' ],
		labels: [ 'iphone', 'imac', 'ibook', 'samsung', 'android' ],
		pointSize: 0,
		lineWidth: 0,
		resize: true,
		fillOpacity: 0.8,
		behaveLikeLine: true,
		gridLineColor: '#e0e0e0',
		hideHover: 'auto'

	} );



} );
</script>