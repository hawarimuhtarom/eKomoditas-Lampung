<?php
include 'koneksi/koneksi.php';
?>
<div class="col-lg-3">
                        <div class="card bg-dark">
                            <div class="testimonial-widget-one p-17">
                                <div class="testimonial-widget-one owl-carousel owl-theme">
                                    
                                    <div class="item">
                                        <div class="testimonial-content">
                                            <div class="testimonial-author">Karin Fitri Liyana</div>
                                            <div class="testimonial-author-position">Founder-Ceo. Dell Corp</div>

                                            <div class="testimonial-text">
                                                <i class="fa fa-quote-left"></i>  Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                                                <i class="fa fa-quote-right"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="testimonial-content">
                                            <div class="testimonial-author">Hawari Muhtarom</div>
                                            <div class="testimonial-author-position">Founder-Ceo. Dell Corp</div>

                                            <div class="testimonial-text">
                                                <i class="fa fa-quote-left"></i>  Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                                                <i class="fa fa-quote-right"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


   
<div class="col-lg-9">
                        <div class="card">
                            <div class="card-title">
                                <h4>Pengelola Website E-Komoditas Lampung </h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                            </tr>
                                        </thead>
                                        <tbody>
<?php
    $sqlquery = "SELECT nmuser, email, foto FROM user WHERE lv_user='admin'";
    $hasil = $kdb->query( $sqlquery);

  while($baris = $hasil->fetch(PDO::FETCH_ASSOC))
{
?>
                                            
                                            <tr>
                                                <td>
                                                    <div class="round-img">
                                                        <a href=""><img src="./upload/image/<?php echo $baris['foto']; ?>" ></a>
                                                    </div>
                                                </td>
                                                <td><?php echo $baris['nmuser']; ?></td>
                                                <td><span class="badge badge-success"><?php echo $baris['email']; ?></span></td>
                                            </tr>
<?php
  }
  ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>