<?php
$a = !empty($_GET['a']) ? $_GET['a'] : "reset";
$id_produksi = !empty($_GET['id']) ? $_GET['id'] : " ";   
$kdb = koneksidatabase();
$a = @$_GET["a"];
$sql = @$_POST["sql"];
switch ($sql) {
    case "insert": sql_insert(); break;
    case "update": sql_update(); break;
    case "delete": sql_delete(); break;	
}

switch ($a) {
    case "reset" :  curd_read();   break;
    case "tambah":  curd_create(); break;	
    case "edit"  :  curd_update($id_produksi); break;	
    case "hapus"  :  curd_delete($id_produksi); break;  	
    default : curd_read(); break;
}


function curd_read()
{ 
  $hasil = sql_select();
  $i=1;

  ?>
<div class="col-md-12"> 
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Data Produksi Panen  </h4>
                                <h6 class="card-subtitle">Mengatur data statistika panen berdasaran Produksi TON / Tahun di daerah Kabupaten Lampung</h6>
                                <?php if(isset($_SESSION['lv_user'])){?>
                                <?php if(($_SESSION['lv_user']=='admin')){?>
                                <a href="index.php?page=5&a=tambah"><span class='btn  btn-success btn-sm'>TAMBAH DATA</span></a>	
                                <?php }}?>
                                <?php if(isset($_SESSION['lv_user'])){?>
                                <a href="./proses_produksi.php"> ! Export ke Excel</a>
                                <?php }?>
                                <div class="table-responsive m-t-40">
                                    <table id="myTable" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Kabupaten</th>
                                                <th>Jenis Komoditas</th>
                                                <th>Produksi ( Ton )</th>
                                                <th>Tahun</th>
                                                <?php if(isset($_SESSION['lv_user'])){?>
                                                <?php if(($_SESSION['lv_user']=='admin')){?>
                                                <th>Action</th>
                                                <?php }}?>
                                                                                              
                                            </tr>
                                        </thead>
                                        <tbody>
 <?php
  while($baris = $hasil->fetch(PDO::FETCH_ASSOC))
  {
  ?>
                                            <tr>
  <td><?php echo $i; ?></td>
  <td><?php echo $baris['nm_kabupaten']; ?></td>
  <td><?php echo $baris['nm_komoditas']; ?></td>
  <td><?php echo $baris['ton']; ?></td>
  <td><?php echo $baris['tahun']; ?></td>
  <?php if(isset($_SESSION['lv_user'])){?>
   <?php if(($_SESSION['lv_user']=='admin')){?>
  <td>
                                                    <a  href="index.php?page=5&a=edit&id=<?php echo $baris['id_produksi']; ?>"><span class='btn  btn-warning btn-sm'>UPDATE</span></a>
                                                    <a  href="index.php?page=5&a=hapus&id=<?php echo $baris['id_produksi']; ?>"><span class='btn  btn-danger btn-sm'>DELETE</span></a>	
<?php }}?>
                                                </td>
                                            </tr>
 <?php
   $i++;  
  }
  ?>
                                        </tbody>
                                    </table>
 <?php
}
 ?>
                                </div>
                            </div>
                        </div>
</div>

<?php 
function formeditor($row)
  {
?>
<div class="container-fluid">
<div class="row">
<div class="col-lg-12"> 
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Data Produksi Panen </h4>
                                <h6 class="card-subtitle">Data Produksi TON/Tahun di daerah Kabupaten Lampung</h6>   
                                <a href="index.php?page=5&a=reset"><span class='btn  btn-warning btn-sm'>Batal</a>
<br>
                                <div class="table-responsive m-t-40">
                                    <table id="myTable" class="table table-hover">
                                        <thead>
<tr>
<td >Kabupaten</td>
    <td><select class="form-control form-control-sm" name="id_kabupaten">
    <?php
    global $kdb;
    $sqlquery = "select id_kabupaten, nm_kabupaten from kabupaten";
    $hasilquery = $kdb->query( $sqlquery);
    while ( $baris = $hasilquery->fetch()) {
    $value = $baris["id_kabupaten"];
    $caption = $baris ["nm_kabupaten"];
    if ($row["id_kabupaten"] == $baris ["id_kabupaten"])
    {$selstr = "selected"; }
    else {$selstr = ""; }
    ?>
    <option value="<?php echo $value ?>" <?php echo $selstr ?>>
    &nbsp; <?php echo $caption; ?> &nbsp;
    </option>
    <?php
    }
    ?>
    </select></td>
</tr>
<tr>
<td >Komoditas</td>
<td><select class="form-control form-control-sm" name="id_komoditas">
    <?php
    global $kdb;
    $sqlquery = "select id_komoditas, nm_komoditas from komoditas";
    $hasilquery = $kdb->query( $sqlquery);
    while ( $baris = $hasilquery->fetch()) {
    $value = $baris["id_komoditas"];
    $caption = $baris ["nm_komoditas"];
    if ($row["id_komoditas"] == $baris ["id_komoditas"])
    {$selstr = "selected"; }
    else {$selstr = ""; }
    ?>
    <option value="<?php echo $value ?>" <?php echo $selstr ?>>
    &nbsp; <?php echo $caption; ?> &nbsp;
    </option>
    <?php
    }
    ?>
    </select></td>
</tr>
<tr>
<td >ton </td>
<td class="form-group" ><input class="form-control"  type="text" name="ton" id="ton" maxlength="25"  value="<?php  echo trim($row["ton"]) ?>" ></td>
</tr>
<tr>
<td >Tahun</td>
<td class="form-group "><input class="form-control"  type="text" name="tahun" id="tahun" maxlength="25"  value="<?php  echo trim($row["tahun"]) ?>" ></td>
</tr>
 </thead>
 <tbody> </tbody>
</table>
</div>



 <p><input class="btn btn-success btn-sm"  type="submit" name="action" value="Simpan" ></p>
 </div>
 </div>
</div>
  </div>
    </div>
<?php  }?>	
<?php 
function curd_create() 
{
?>

<form action="index.php?page=5&a=reset" method="post">
<input type="hidden" name="sql" value="insert" >
<?php
$row = array(
  "id_kabupaten" => "",
    "ton" => "",
    "tahun" => "",
    "id_komoditas" => ""
   ) ;
formeditor($row)
?>


</form>
<?php } ?>

<?php 
function curd_update($id_produksi) 
{
global $kdb;
$hasil2 = sql_select_byid($id_produksi);
$row =  $hasil2->fetch(PDO::FETCH_ASSOC);
?>

<br>
<form action="index.php?page=5&a=reset" method="post">
<input type="hidden" name="sql" value="update" >
<input type="hidden" name="id_produksi" value="<?php  echo $id_produksi; ?>" >
<?php
formeditor($row)
?>
</form>
<?php } ?>

<?php 
function curd_delete($id_produksi) 
{
global $kdb;
$hasil2 = sql_select_byid($id_produksi);
$row =  $hasil2->fetch(PDO::FETCH_ASSOC);
?>

<div class="container-fluid">
<div class="row">

<div class="col-lg-12"> 
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Penghapusan Data</h4>
<a href="index.php?page=5&a=reset"><span class='btn  btn-warning btn-sm'>Batal</a>
<br>
<form action="index.php?page=5&a=reset" method="post">
<input type="hidden" name="sql" value="delete" >
<input type="hidden" name="id_produksi" value="<?php  echo $id_produksi; ?>" >
<h5> Anda yakin akan menghapus data  </h5>
<p><input type="submit" name="action" value="Delete" ></p>
                            </div>
                            </div>
    </div>
    </div>
    </div>
</form>
<?php } ?>


<?php 
function koneksidatabase()
{
    include('./koneksi/koneksi.php');
	return $kdb;
}

function sql_select_byid($id_produksi)
{
  global $kdb;
  $hasil2 = $kdb->query(" select * from data_produksi where id_produksi = ".$id_produksi);
  return $hasil2;
}
function sql_select()
{
  global $kdb;
  $sql = "select b.nm_kabupaten, c.nm_komoditas, a.* FROM data_produksi as a, kabupaten as b, komoditas as c where a.id_kabupaten=b.id_kabupaten and a.id_komoditas=c.id_komoditas ORDER BY a.tahun DESC";
  $hasil2 = $kdb->query($sql);
  return $hasil2;
  
}

function sql_insert()
{
  global $kdb;
  global $_POST; 
  
  $id_kabupaten = $_POST["id_kabupaten"];
  $ton = $_POST["ton"];
  $tahun = $_POST["tahun"];
  $id_komoditas = $_POST["id_komoditas"];
  $sql  = $kdb->query("INSERT INTO data_produksi(id_kabupaten,ton,tahun,id_komoditas) VALUES ('$id_kabupaten','$ton','$tahun','$id_komoditas')");			  
  
}

function sql_update()
{
  global $kdb; 
  global $_POST; 
  
   $id_produksi = $_POST["id_produksi"];
  $id_kabupaten = $_POST["id_kabupaten"];
  $ton = $_POST["ton"];
  $tahun = $_POST["tahun"];
  $id_komoditas = $_POST["id_komoditas"];
    $sql  = $kdb->query("UPDATE `data_produksi` SET `id_kabupaten` = '$id_kabupaten', `ton` = '$ton', `tahun` = '$tahun', `id_komoditas` = '$id_komoditas' WHERE `id_produksi` = ".$id_produksi);			  

}

function sql_delete()
{
  global $kdb;
  global $_POST; 
  $sql  = $kdb->query(" delete from `data_produksi` where id_produksi = ".$_POST["id_produksi"]);			  
 
}
?>