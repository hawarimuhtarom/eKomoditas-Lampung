<?php
$a = !empty($_GET['a']) ? $_GET['a'] : "reset";
$id_kabupaten = !empty($_GET['id']) ? $_GET['id'] : " ";   
$kdb = koneksidatabase();
$a = @$_GET["a"];
$sql = @$_POST["sql"];
switch ($sql) {
    case "insert": sql_insert(); break;
    case "update": sql_update(); break;
    case "delete": sql_delete(); break;	
}

switch ($a) {
    case "reset" :  curd_read();   break;
    case "tambah":  curd_create(); break;	
    case "edit"  :  curd_update($id_kabupaten); break;	
    case "hapus"  :  curd_delete($id_kabupaten); break;  	
    default : curd_read(); break;
}


function curd_read()
{ 
  $hasil = sql_select();
  $i=1;

  ?>
<div class="col-md-12"> 
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Data Lokasi   </h4>
                                <h6 class="card-subtitle">Mengatur data Lokasi di daerah Kabupaten Lampung</h6>
                                <?php if(isset($_SESSION['lv_user'])){?>
                                <?php if(($_SESSION['lv_user']=='admin')){?>
                                <a href="index.php?page=9&a=tambah"><span class='btn  btn-success btn-sm'>TAMBAH DATA</span></a>	
                                <?php }}?>
                                <div class="table-responsive m-t-40">
                                    <table id="myTable" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Kabupaten</th>
                                                <th>Provinsi</th>
                                                <th>Maps</th>
                                                <?php if(isset($_SESSION['lv_user'])){?>
                                                <?php if(($_SESSION['lv_user']=='admin')){?>
                                                <th>Action</th>
                                                 <?php }}?>                                             
                                            </tr>
                                        </thead>
                                        <tbody>
 <?php
  while($baris = $hasil->fetch(PDO::FETCH_ASSOC))
  {
  ?>
                                            <tr>
  <td><?php echo $i; ?></td>
  <td><?php echo $baris['nm_kabupaten']; ?></td>
  <td><?php echo $baris['nm_provinsi']; ?></td>
  <td> <?php echo ''
  . '<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal'.$baris['id_kabupaten'].'">Lihat</button>
<!-- Modal -->
<div id="myModal'.$baris['id_kabupaten'].'" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
       
        <h4 class="modal-title">Maps Lokasi</h4>
      </div>
      <div class="modal-body">
        <iframe src="'.$baris['maps'].'" width="470" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
      </div>
         
      <div class="modal-footer">
          <a href="index.php?page=9"> Keluar</a>
        </div>
    </div>

  </div>
</div>' ?></td>
    <?php if(isset($_SESSION['lv_user'])){?>
  <?php if(($_SESSION['lv_user']=='admin')){?>
  <td>
                                                      <a  href="index.php?page=9&a=edit&id=<?php echo $baris['id_kabupaten']; ?>"><span class='btn  btn-warning btn-sm'>UPDATE</span></a>	
                                                    <a  href="index.php?page=9&a=hapus&id=<?php echo $baris['id_kabupaten']; ?>"><span class='btn  btn-danger btn-sm'>DELETE</span></a>	
                                                </td>
                                                  <?php }}?>
                                            </tr>
 <?php
   $i++;  
  }
  ?>
                                        </tbody>
                                    </table>
 <?php
}
 ?>
                                </div>
                            </div>
                        </div>
</div>

<?php 
function formeditor($row)
  {
?>
<div class="container-fluid">
<div class="row">
<div class="col-lg-12"> 
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Data Lokasi </h4>
                                <h6 class="card-subtitle">Data Lokasi daerah Kabupaten Lampung</h6>   
                                <a href="index.php?page=9&a=reset"><span class='btn  btn-warning btn-sm'>Batal</a>
<br>
                                <div class="table-responsive m-t-40">
                                    <table id="myTable" class="table table-hover">
                                        <thead>

<tr>
<td >Nama Kabupaten </td>
<td class="form-group" ><input class="form-control"  type="text" name="nm_kabupaten" id="nm_kabupaten" maxlength="25"  value="<?php  echo trim($row["nm_kabupaten"]) ?>" ></td>
</tr>
<tr>
<td >Provinsi</td>
<td class="form-group "><input class="form-control"  type="text" name="nm_provinsi" id="nm_provinsi" maxlength="25" placeholder="Lampung"  value="<?php  echo "Lampung" ?>" ></td>
</tr>
<tr>
<td >Maps</td>
<td class="form-group "><input class="form-control"  type="text" name="maps" id="maps" maxlength="25"  value="<?php  echo trim($row["maps"]) ?>" ></td>
</tr>
 </thead>
 <tbody> </tbody>
</table>
</div>



 <p><input class="btn btn-success btn-sm"  type="submit" name="action" value="Simpan" ></p>
 </div>
 </div>
</div>
  </div>
    </div>
<?php  }?>	
<?php 
function curd_create() 
{
?>

<form action="index.php?page=9&a=reset" method="post">
<input type="hidden" name="sql" value="insert" >
<?php
$row = array(
  "nm_kabupaten" => "",
    "nm_provinsi" => "",
    "maps" => ""
   ) ;
formeditor($row)
?>


</form>
<?php } ?>

<?php 
function curd_update($id_kabupaten) 
{
global $kdb;
$hasil2 = sql_select_byid($id_kabupaten);
$row =  $hasil2->fetch(PDO::FETCH_ASSOC);
?>

<br>
<form action="index.php?page=9&a=reset" method="post">
<input type="hidden" name="sql" value="update" >
<input type="hidden" name="id_kabupaten" value="<?php  echo $id_kabupaten; ?>" >
<?php
formeditor($row)
?>
</form>
<?php } ?>

<?php 
function curd_delete($id_kabupaten) 
{
global $kdb;
$hasil2 = sql_select_byid($id_kabupaten);
$row =  $hasil2->fetch(PDO::FETCH_ASSOC);
?>

<div class="container-fluid">
<div class="row">

<div class="col-lg-12"> 
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Penghapusan Data</h4>
<a href="index.php?page=9&a=reset"><span class='btn  btn-warning btn-sm'>Batal</a>
<br>
<form action="index.php?page=9&a=reset" method="post">
<input type="hidden" name="sql" value="delete" >
<input type="hidden" name="id_kabupaten" value="<?php  echo $id_kabupaten; ?>" >
<h5> Anda yakin akan menghapus data  </h5>
<p><input type="submit" name="action" value="Delete" ></p>
                            </div>
                            </div>
    </div>
    </div>
    </div>
</form>
<?php } ?>


<?php 
function koneksidatabase()
{
    include('./koneksi/koneksi.php');
	return $kdb;
}

function sql_select_byid($id_kabupaten)
{
  global $kdb;
  $hasil2 = $kdb->query(" select * from kabupaten where id_kabupaten = ".$id_kabupaten);
  return $hasil2;
}
function sql_select()
{
  global $kdb;
  $sql = "select * from kabupaten";
  $hasil2 = $kdb->query($sql);
  return $hasil2;
  
}

function sql_insert()
{
  global $kdb;
  global $_POST; 
  
  $nm_kabupaten = $_POST["nm_kabupaten"];
  $nm_provinsi = $_POST["nm_provinsi"];
  $maps = $_POST["maps"];
  $sql  = $kdb->query("INSERT INTO kabupaten(nm_kabupaten,nm_provinsi,maps) VALUES ('$nm_kabupaten','$nm_provinsi','$maps')");			  
  
}

function sql_update()
{
 global $kdb;
  global $_POST; 
  
  $nm_kabupaten = $_POST["nm_kabupaten"];
  $nm_provinsi = $_POST["nm_provinsi"];
  $maps = $_POST["maps"];
  $sql  = $kdb->query("UPDATE `kabupaten` SET `nm_kabupaten` = '$nm_kabupaten', `nm_provinsi` = '$nm_provinsi', `maps` = '$maps' WHERE `id_kabupaten` = ".$id_kabupaten);			  

}

function sql_delete()
{
  global $kdb;
  global $_POST; 
  $sql  = $kdb->query(" delete from `kabupaten` where id_kabupaten = ".$_POST["id_kabupaten"]);			  
 
}
?>


